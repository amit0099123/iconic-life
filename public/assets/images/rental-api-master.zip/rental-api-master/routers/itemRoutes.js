const express = require('express');
const { getAllListings, getListingById } = require('../controllers/itemController');
const { get } = require('http');
const router = express.Router();


router.get('/', getAllListings)

router.get('/:id', getListingById)







module.exports = router;