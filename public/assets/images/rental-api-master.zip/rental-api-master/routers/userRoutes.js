const express = require("express");
const {
  createUser,
  getAllUsers,
  getUser,
  updateUser,
  deleteUser,
  createUserListing,
  getUserListings,
  viewUserListing,
  updateUserListing,
  deleteUserListing,
  getActiveRentals,
  getActiveRentalById,
  initiateRental,
  updateRentalInfo,
  deleteRentalById,
} = require("../controllers/userController");
const router = express.Router();
const authMiddleware = require('../middleware/auth');

router.get("/", (req, res) => {
  res.status(200).json({ message: "Welcome to the home page" });
});

//USERS
router.route("/users").get(getAllUsers);
router.post("/register", createUser);
router.route("/users/:id").get(authMiddleware, getUser).patch(authMiddleware, updateUser).delete(authMiddleware, deleteUser);

//LISTINGS
router
  .route("/users/:id/listings")
  .get(authMiddleware, getUserListings)
  .post(authMiddleware, createUserListing);
router
  .route("/users/:userId/listings/:listingId")
  .get(authMiddleware, viewUserListing)
  .patch(authMiddleware, updateUserListing)
  .delete(authMiddleware, deleteUserListing);


//RENTALS
router.route("/users/:userId/rentals").get(authMiddleware, getActiveRentals).post(authMiddleware, initiateRental);
router.route("/users/:userId/rentals/:rentalId").get(authMiddleware, getActiveRentalById).patch(authMiddleware, updateRentalInfo).delete(authMiddleware, deleteRentalById);


module.exports = router;
