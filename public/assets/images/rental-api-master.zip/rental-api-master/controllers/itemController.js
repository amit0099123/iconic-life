const getAllListings = async (req, res) => {
    res.status(200).json({ message: 'Welcome to the listings page' })
}


const getListingById = async (req, res) => {
    res.status(200).json({ message: 'Welcome to the listing\'s page' })
}


module.exports = { getAllListings, getListingById }