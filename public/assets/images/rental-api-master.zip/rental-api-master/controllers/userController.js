const { User, Item, RentedItem } = require("../models/user");
const jwt = require("jsonwebtoken");

const getAllUsers = async (req, res) => {
  const users = await User.find({});
  res
    .status(200)
    .json({ status: "success", nbOfHits: users.length, message: users });
};

const createUser = async (req, res) => {
  const { name, email, password } = req.body;

  // Check if all required fields are provided
  if (!name || !email || !password) {
    return res.status(400).json({ status: "error", message: "Please provide name, email, and password" });
  }
  const newUser = await User.create({ ...req.body });
  const token = newUser.createJWT();
  res.status(201).json({ status: "success", message: {user: {name: newUser.name}, token} });
};

const getUser = async (req, res) => {
  const { id } = req.params;
  const user = await User.findOne({ _id: id });
  if (!user) {
    return res.status(404).json({ status: "fail", message: "User not found" });
  }
  res.status(200).json({ status: "success", message: user });
};

const updateUser = async (req, res) => {
  const { id } = req.params;
  const user = await User.findOneAndUpdate({ _id: id }, req.body, {
    new: true,
    runValidators: true,
  });
  if (!user) {
    return res
      .status(404)
      .json({ status: "fail", message: `No user with id: ${id}` });
  }
  res.status(200).json({ status: "success", message: user });
};

const deleteUser = async (req, res) => {
  const { id } = req.params;
  const user = await User.findOneAndDelete({ _id: id });
  if (!user) {
    return res
      .status(404)
      .json({ status: "fail", message: `No user with id: ${id}` });
  }
  res
    .status(200)
    .json({ status: "success", message: `Deleted user with id: ${id}` });
};

const getUserListings = async (req, res) => {
  const { id } = req.params;
  const user = await User.findOne({ _id: id });
  if (!user) {
    return res.status(404).json({ status: "fail", message: "User not found" });
  }

  const listings = await Item.find({ _id: { $in: user.listedItems } });

  res.status(200).json({ status: "success", data: listings });
};

const createUserListing = async (req, res) => {
  const { id } = req.params; // Assuming this is the user's ID
  const { name, description, price, status, collateral } = req.body;
  try {
    // Create the new item listing
    const newListing = await Item.create({
      name,
      description,
      price,
      owner: id,
      status,
      collateral,
    });

    // Update the user document to include the new item's ID in its listedItems array
    const user = await User.findByIdAndUpdate(
      id,
      { $push: { listedItems: newListing._id } }, // Use $push to add the new item's ID to the array
      { new: true, runValidators: true }
    );
    res.status(201).json({ status: "success", data: { user, newListing } });
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
};

const viewUserListing = async (req, res) => {
  const { userId, listingId } = req.params; // Adjusted to match the expected path parameters

  try {
    const item = await Item.findOne({ _id: listingId, owner: userId }); // Find the user first
    if (!item) {
      return res
        .status(404)
        .json({ status: "error", message: "Item not found" });
    }
    // If the item exists and belongs to the user, return it
    res.status(200).json({ status: "success", data: item });
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
};

const updateUserListing = async (req, res) => {
  const { userId, listingId } = req.params; // Adjusted to match the expected path parameters
  const updateFields = req.body;

  try {
    let item = await Item.findOne({ _id: listingId, owner: userId }); // Find the user first
    if (!item) {
      return res
        .status(404)
        .json({ status: "error", message: "Item not found" });
    }

    item = Object.assign(item, updateFields); // Update the item with the new fields
    await item.save();

    // If the item exists and belongs to the user, return it
    res.status(200).json({ status: "success", data: item });
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
};

const deleteUserListing = async (req, res) => {
  const { userId, listingId } = req.params;

  let item = await Item.findOneAndDelete({ _id: listingId, owner: userId }); // Find the user first
  if (!item) {
    return res.status(404).json({ status: "error", message: "Item not found" });
  }
  res.status(200).json({ status: "success", message: "Item deleted" });
};

const getActiveRentals = async (req, res) => {
  const { userId } = req.params;
  const user = await User.findOne({ _id: userId });
  if (!user) {
    return res.status(404).json({ status: "fail", message: "User not found" });
  }

  // const listings = await Item.find({ '_id': { $in: user.listedItems } });
  const rentals = await RentedItem.find({ renter: userId });
  res.status(200).json({ status: "success", message: rentals });
};

const getActiveRentalById = async (req, res) => {
  const { userId, rentalId } = req.params;
  const rental = await RentedItem.findOne({ _id: rentalId, renter: userId });
  if (!rental) {
    return res
      .status(404)
      .json({ status: "fail", message: "Rental not found" });
  }
  res.status(200).json({ message: rental });
};

const initiateRental = async (req, res) => {
  const { userId } = req.params;
  const { itemId, startDate, endDate } = req.body;
  // validate the time
  const now = new Date();
  if (new Date(startDate) <= now) {
    return res
      .status(400)
      .json({ status: "fail", message: "Start date must be in the future." });
  }
  if (new Date(endDate) <= now || new Date(endDate) <= new Date(startDate)) {
    return res
      .status(400)
      .json({ status: "fail", message: "End date must be after start date." });
  }

  const item = await Item.findOne({ _id: itemId, status: "available" });
  if (item.status !== "available") {
    return res
      .status(400)
      .json({ status: "fail", message: "Item is not available for rent" });
  }

  const rental = await RentedItem.create({
    item: itemId,
    renter: userId,
    startDate,
    endDate,
    paidCollateral: true, // Assuming payment is handled separately and successfully
  });

  // Update the item's status to rentInitiated
  await Item.findOneAndUpdate(
    { _id: itemId },
    { status: "rentInitiated" },
    { new: true, runValidators: true }
  );

  await User.findOneAndUpdate(
    { _id: userId },
    { $push: { activeRentals: rental._id } },
    { new: true, runValidators: true }
  );

  res.status(201).json({ message: rental });
};

const updateRentalInfo = async (req, res) => {
  const { userId, rentalId } = req.params;
  const { startDate, endDate } = req.body;
  const now = new Date();

  try {
    const rental = await RentedItem.findOne({ _id: rentalId, renter: userId });
    if (!rental) {
      return res
        .status(404)
        .json({ status: "fail", message: "Rental not found" });
    }

    if (!rental.paidCollateral) {
      return res
        .status(400)
        .json({ status: "fail", message: "You have not paid the collateral" });
    }

    if (rental.status === "completed") {
      return res
        .status(400)
        .json({
          status: "fail",
          message: "Cannot modify a rental that has been completed",
        });
    }

    // Combine conditions to simplify logic
    if (rental.status === "active") {
      if (now > new Date(startDate)) {
        return res
          .status(400)
          .json({
            status: "fail",
            message:
              "You cannot modify the start date, given that the rental has begun",
          });
      }

      if (now > new Date(endDate)) {
        return res
          .status(400)
          .json({
            status: "fail",
            message: "You cannot modify the end date to a time in the past!",
          });
      }
    }

    if (new Date(endDate) <= new Date(startDate)) {
      return res
        .status(400)
        .json({ status: "fail", message: "End Date must be after Start Date" });
    }

    // Determine fields to update based on rental status
    const updateFields =
      rental.status === "pending" ? { startDate, endDate } : { endDate };

    const updatedRental = await RentedItem.findByIdAndUpdate(
      rentalId,
      updateFields,
      { new: true, runValidators: true }
    );

    res
      .status(200)
      .json({
        status: "success",
        message: "Rental updated successfully",
        data: updatedRental,
      });
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
};

const deleteRentalById = async (req, res) => {
  const { userId, rentalId } = req.params;
  const rental = await RentedItem.findOneAndDelete({
    _id: rentalId,
    renter: userId,
  });
  if (!rental) {
    return res
      .status(404)
      .json({ status: "fail", message: "Rental not found" });
  }
  res.status(200).json({ message: `Delete user's rental with id:${rentalId}` });
};

module.exports = {
  getAllUsers,
  createUser,
  getUser,
  updateUser,
  deleteUser,
  createUserListing,
  getUserListings,
  viewUserListing,
  updateUserListing,
  deleteUserListing,
  getActiveRentals,
  getActiveRentalById,
  initiateRental,
  updateRentalInfo,
  deleteRentalById,
};
