const CustomAPIError = require("../errors/custom-error");
const jwt = require("jsonwebtoken");
const { User } = require("../models/user");
const bcrypt = require("bcryptjs");

const register = async (req, res) => {
  const newUser = await User.create({ ...req.body });
  const token = newUser.createJWT();
  res.status(201).json({
    status: "success",
    message: { user: { name: newUser.name }, token },
  });
};

const login = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    throw new CustomAPIError("Please provide email and password", 400);
  }

  const user = await User.findOne({ email });
  if (!user) {
    throw new CustomAPIError("No user with that email", 404);
  }

  const isPasswordCorrect = await user.comparePassword(password);
  if (!isPasswordCorrect) {
    throw new CustomAPIError("Password is incorrect", 400);
  }

  const token = user.createJWT();
  res.status(200).json({ status: "success", message: { user: { name: user.name }, token } });

//   const id = new Date().getDate();
//   const token = jwt.sign({ id, username }, process.env.JWT_SECRET, {
//     expiresIn: "30d",
//   });
//   res.status(200).json({ msg: `user ${username} logged in`, token });
};

const dashboard = async (req, res) => {
  const luckyNumber = Math.floor(Math.random() * 100);
  res.status(200).json({
    msg: `Hello ${req.user.username}, How are you`,
    secret: `Here is your authorized data, lucky number: ${luckyNumber}`,
  });

  // try {
  //     const decoded = jwt.verify(token, process.env.JWT_SECRET);
  //     const {id, username} = decoded;
  //     // res.status(200).json({msg: `user ${id} - ${username} is logged in`});
  // } catch (error) {
  //     throw new CustomAPIError('Not authorized', 401);

  // }
};

module.exports = {
  login,
  dashboard,
  register,
};
