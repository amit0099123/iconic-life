const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const itemSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please provide a name'],
        minlength: 3,
        maxlength: 50
    },
    description: {
        type: String,
        required: [true, 'Please provide a description'],
        minlength: 10,
        maxlength: 500
    },
    price: {
        type: Number,
        required: [true, 'Please provide a price'],
        min: 0
    },
    owner: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    status: {
        type: String,
        enum: ['available', 'rentInitiated', 'rented'],
        default: 'available'
    },
    collateral: {
        type: Number,
        required: [true, 'Please provide a collateral'],
        min: 0
    }
});

const rentedItemSchema = new mongoose.Schema({
    item: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Item',
        required: true
    },
    renter: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    startDate: {
        type: Date,
        required: [true, 'Please provide a start date']
    },
    endDate: {
        type: Date,
        required: [true, 'Please provide an end date']
    },
    paidCollateral: {
        type: Boolean,
        required: [true, 'Please provide a collateral'],
        default: false
    },
    status: {
        type: String,
        enum: ['pending', 'active', 'completed'],
        default: 'pending'
    }

})

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please provide a name'],
        minlength: 3,
        maxlength: 50
    },
    email: {
        type: String,
        required: [true, 'Please provide an email'],
        unique: true,
        match: [/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, 'Please provide a valid email'],
        unique: true
    },
    password: {
        type: String,
        required: [true, 'Please provide a password'],
        minlength: 6
    },
    listedItems: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Item' }],
    activeRentals: [{ type: mongoose.Schema.Types.ObjectId, ref: 'RentedItem' }],
})

userSchema.pre('save', async function (next) {
    // Check if password field is modified
    if (!this.isModified('password')) {
        return next();
    }
    try {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
        console.log('Password hashed')
        next();
    } catch (error) {
        next(error);
    }
});


userSchema.methods.createJWT = function () {
    return jwt.sign({ userId: this._id, name: this.name, email: this.email }, process.env.JWT_SECRET, {
        expiresIn: "30d"
    })
}


userSchema.methods.comparePassword = async function (candidatePassword) {
    const isMatch = await bcrypt.compare(candidatePassword, this.password);
    return isMatch;
}

const User = mongoose.model('User', userSchema);
const Item = mongoose.model('Item', itemSchema);
const RentedItem = mongoose.model('RentedItem', rentedItemSchema);

module.exports = { User, Item, RentedItem };
//user has name -- String
//user has email -- String
//user has password -- String
//user has listed items -- Array of ObjectIds
//user has active rentals -- Array of ObjectIds
//user has completed rentals -- Array of ObjectIds
