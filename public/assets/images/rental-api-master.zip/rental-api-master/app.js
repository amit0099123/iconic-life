
const express = require('express');
require('express-async-errors');
require('dotenv').config();
const app = express();
const PORT = process.env.PORT || 3000;
const userRouter = require('./routers/userRoutes');
const itemRouter = require('./routers/itemRoutes');
const connectDb = require('./db/connect');
const mainRouter = require('./routers/login');
const errorHandlerMiddleware = require('./middleware/error-handler');
const notFoundMiddleware = require('./middleware/not-found');

app.use(express.json());
 

//middleware
app.use('/api/v1', userRouter);
app.use('/api/v1/listings', itemRouter);
app.use('/api/v1/auth', mainRouter);
app.use(notFoundMiddleware)
app.use(errorHandlerMiddleware)


const start = async () => {
    try {
        await connectDb(process.env.MONGO_URI);
        console.log('Database connected!')

        app.listen(PORT, console.log(`Server is running on port ${PORT}`));
        
    } catch (error) {
        console.log(error)
    }
}


start().catch((err) => {
    console.log(err)
    process.exit(1)
})
    
