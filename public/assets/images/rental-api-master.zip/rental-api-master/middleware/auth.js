const User = require('../models/user');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');


const authenticationMiddleware = async (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        throw new CustomAPIError('No token provided', 401);
    }

    const token = authHeader.split(' ')[1];

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const {id, name, email} = decoded;
        req.user = {id, name, email};
        next();
   } catch (error) {
        throw new CustomAPIError('Not authorized', 401);
        
    }
}


// const registrationMiddleware = async (req, res, next) => {
//     const {name, email, password} = req.body;

//     if (!name || !email || !password) {
//         throw new CustomAPIError('Please provide name, email and password', 400);
//     }
//     //TODO: check if user already exists
//     const user = await User.findOne({email});
//     if (user) {
//         throw new CustomAPIError('User already exists', 400);
//     }

//     const salt = await bcrypt.genSalt(10);
//     const hashedPassword = await bcrypt.hash(password, salt);

//     //TODO: hash the password
//     const tempUser = {name, email, password: hashedPassword} 
//     req.user = tempUser;
//     next();
// }


module.exports = authenticationMiddleware;